import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retailerhome',
  templateUrl: './retailerhome.component.html',
  styleUrls: ['./retailerhome.component.css']
})
export class RetailerhomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
