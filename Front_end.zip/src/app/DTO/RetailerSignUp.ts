export class RetailerSignUp
{
    uName : string;
    uEmail : string;
    uPassword : string;
    uAddress : string;
    uPhone : number;
 
}