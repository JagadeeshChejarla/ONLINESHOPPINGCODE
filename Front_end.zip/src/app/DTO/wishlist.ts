export class Wishlist
{
    wId : number;
	pId : number;
	pImage1 : string;
	pName : string;
	pBrand : string;
	pPrice : number;
}