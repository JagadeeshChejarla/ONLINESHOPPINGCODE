export class PlaceOrder{
	pId:number;
	pImage:string;
	pBrand: string;
	pOrderDate: string;
	pQty: number;
	pType: string;
	pName: string;
	pPrice: number;
}