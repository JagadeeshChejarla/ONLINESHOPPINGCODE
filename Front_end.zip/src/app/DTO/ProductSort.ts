export class ProductSort{
     pId : number;
     pName : string;
	pBrand: string;
	pPrice: number;
     pImage1 : string;
     pImage2: string;
	 pImage3: string;
	pImage4: string;
	pDescription: string;
}