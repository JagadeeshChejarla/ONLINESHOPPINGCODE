export class AddProduct
{
    pBrand:string;
    pCategory:string;
    pSubCategory:string;
    pDescription:string;
    pImage1:string;
	pImage2:string;
	pImage3:string;
	pImage4:string;
	pName:string;
	pPrice:number;
	pQty:number;
}