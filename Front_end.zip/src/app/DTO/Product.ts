export class Product
{
    proImg1 : string;
    proImg2 : string;
    proImg3 : string;
    proDescription : string;
    proId : number;
    proName : string;
    proBrand : string;
    proPrice : number;
}